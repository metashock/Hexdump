<?php

ini_set('display_errors', 1);
ini_set('error_reporting', E_ALL | E_STRICT);

require_once 'Hexdump.php';

// we display ourself
$data =@file_get_contents($argv[0]);
if(!$data) {
    die('cannot open ' . $argv[0]);
}

// display with default settings
hexdump($data);

// display 8 bytes per line
hexdump($data, 8);

// display uppercased hex chars
hexdump($data, 16, PHP_EOL, TRUE);

// display as html
echo '<pre>';
hexdump($data, 16, '<br />');
echo '</pre>' . PHP_EOL;

// test exceptions
try { 
    hexdump (1);
} catch (InvalidArgumentException $e) {
    echo 'OK', PHP_EOL;
}

try { 
    hexdump ('test', 'test');
} catch (InvalidArgumentException $e) {
    echo 'OK', PHP_EOL;
}

try { 
    hexdump ('test', 0);
} catch (UnexpectedValueException $e) {
    echo 'OK', PHP_EOL;
}

try { 
    hexdump ('test', 'test', 1);
} catch (InvalidArgumentException $e) {
    echo 'OK', PHP_EOL;
}

try { 
    hexdump ('test', 'test', PHP_EOL, 2);
} catch (InvalidArgumentException $e) {
    echo 'OK', PHP_EOL;
}




